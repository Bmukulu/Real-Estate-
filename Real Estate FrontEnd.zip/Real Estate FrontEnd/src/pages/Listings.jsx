import React from "react";
import { Link } from "react-router-dom";
import rollingViewProperty from "./data/rollingViewProperty.jsx";

export default function Listings() {
  // Later you can add more properties, but for now we use only one.
  const properties = [rollingViewProperty];

  return (
    <div style={{ maxWidth: "900px", margin: "auto", padding: "20px" }}>
      <h1 style={{ marginBottom: "20px" }}>Available Listings</h1>

      {properties.map((property) => (
        <Link
          key={property.id}
          to={`/property/${property.id}`}
          style={{
            textDecoration: "none",
            color: "inherit",
          }}
        >
          <div
            style={{
              border: "1px solid #ddd",
              borderRadius: "10px",
              overflow: "hidden",
              marginBottom: "20px",
              boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
            }}
          >
            <img
              src={property.images[0]}
              alt={property.address}
              style={{
                width: "100%",
                height: "220px",
                objectFit: "cover",
              }}
            />

            <div style={{ padding: "15px" }}>
              <h2 style={{ marginBottom: "5px" }}>{property.address}</h2>
              <p style={{ margin: 0 }}>
                <strong>${property.price.toLocaleString()}</strong> ·{" "}
                {property.beds} beds · {property.baths} baths ·{" "}
                {property.sqft.toLocaleString()} sqft
              </p>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}
