import MortgageCalculator from "../components/MortgageCalculator";
import SearchBar from "../components/searchbar";
import Listings from "../pages/Listings";

export default function Home() {
  return (
    <div>
      <h1>Real Estate Tracker 🏡</h1>
      <MortgageCalculator />
      <SearchBar />
      <Listings />
    </div>
  );
}
