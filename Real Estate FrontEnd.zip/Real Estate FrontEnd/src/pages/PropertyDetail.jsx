import React from "react"
import rollingViewProperty from "src/data/rollingViewProperty";
import ImageCarousel from "/src/components/ImageCarousel";

export default function PropertyDetail() {
  const property = rollingViewProperty;

  return (
    <div style={{ maxWidth: "800px", margin: "auto", padding: "20px" }}>
      <h1>{property.address}</h1>
      <p>
        <strong>Price:</strong> ${property.price.toLocaleString()}
      </p>
      <p>
        <strong>Beds:</strong> {property.beds} · <strong>Baths:</strong> {property.baths} ·{" "}
        <strong>Sqft:</strong> {property.sqft} · <strong>Year Built:</strong> {property.yearBuilt}
      </p>

      <ImageCarousel images={property.images} />
    </div>
  );
}
