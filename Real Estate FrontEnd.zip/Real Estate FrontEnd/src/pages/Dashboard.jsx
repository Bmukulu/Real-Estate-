import React from "react";
import { Link } from "react-router-dom";
import rollingViewProperty from "../data/rollingViewProperty";

export default function Dashboard() {
  return (
    <div style={{ maxWidth: "900px", margin: "auto", padding: "20px" }}>
      <h1 style={{ marginBottom: "10px" }}>Welcome to Your Dashboard</h1>
      <p style={{ marginBottom: "30px" }}>
        Manage your listings, view property details, and calculate mortgages.
      </p>

      {/* Featured Property Section */}
      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: "10px",
          overflow: "hidden",
          marginBottom: "30px",
          boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
        }}
      >
        <img
          src={rollingViewProperty.images[0]}
          alt={rollingViewProperty.address}
          style={{
            width: "100%",
            height: "250px",
            objectFit: "cover",
          }}
        />

        <div style={{ padding: "15px" }}>
          <h2>{rollingViewProperty.address}</h2>
          <p>
            <strong>${rollingViewProperty.price.toLocaleString()}</strong> ·{" "}
            {rollingViewProperty.beds} beds · {rollingViewProperty.baths} baths ·{" "}
            {rollingViewProperty.sqft.toLocaleString()} sqft
          </p>

          <Link
            to={`/property/${rollingViewProperty.id}`}
            style={{ color: "#0066cc", textDecoration: "none" }}
          >
            → View Property Details
          </Link>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div style={{ display: "flex", gap: "20px" }}>
        <Link
          to="/listings"
          style={{
            padding: "12px 20px",
            background: "#0066cc",
            color: "white",
            borderRadius: "8px",
            textDecoration: "none",
          }}
        >
          View All Listings
        </Link>

        <Link
          to="/mortgage"
          style={{
            padding: "12px 20px",
            background: "#00a86b",
            color: "white",
            borderRadius: "8px",
            textDecoration: "none",
          }}
        >
          Mortgage Calculator
        </Link>
      </div>
    </div>
  );
}
