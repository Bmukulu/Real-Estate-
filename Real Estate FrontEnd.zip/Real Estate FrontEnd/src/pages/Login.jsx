export default function Login() {
  return (
    <div>
      <h2>Login</h2>
      <form>
        <input placeholder="Email" />
        <input placeholder="Password" type="password" />
        <button>Log In</button>
      </form>
    </div>
  );
}
