const rollingViewProperty = {
  id: "1366-rollingview",
  address: "1366 Rolling View Way, Dacula, GA 30019",
  price: 440000,
  beds: 5,
  baths: 3,
  sqft: 2893,
  yearBuilt: 2016,
  images: [
    "https://www.redfin.com/GA/Dacula/1366-Rolling-View-Way-SE-30019/unit-244/home/112964892"
  ]
};

export default rollingViewProperty;
