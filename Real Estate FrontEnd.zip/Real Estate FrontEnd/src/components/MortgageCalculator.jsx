import { useState } from "react";

const MortgageCalculator = () => {
  const [price, setPrice] = useState(300000);
  const [downPayment, setDownPayment] = useState(60000);
  const [interestRate, setInterestRate] = useState(5);
  const [LoanTerm, setLoanTerm] = useState(30);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  const calculatePayment = () => {
    const principal = price - downPayment;
  const monthlyRate = interestRate / 100 / 12;
  const n = loanTerm * 12;
  const payment =
    (principal *monthlyRate) / (1 - Math.pow(1 + MonthlyRate, -n));
  setMonthlyPayment(payment.toFixed(2));
  };

  return (
    <div className="max-w-md mx-auto bg-white shadow-x1 rounded-2x-1 p-6">
      <h2 className="text-xl font-semibold mb-4">Mortgage Calculator 🏠</h2>

      <label>Home Price</label>
      <input value={price} onChange={(e) => setPrice(+e.target.value)} />

      <label>Down Payment</label>
      <input value={down} onChange={(e) => setDown(+e.target.value)} />

      <label>Interest Rate (%)</label>
      <input value={rate} onChange={(e) => setRate(+e.target.value)} />

      <label>Term (Years)</label>
      <input value={years} onChange={(e) => setYears(+e.target.value)} />

      <p><strong>Monthly Payment:</strong> ${monthlyPayment.toFixed(2)}</p>
    </div>
  );
}
