// PropertyCard.jsx
const PropertyCard = () => {
  const property = {
    title: "Real Estate",
    location: "1366 Rolling View Way, Dacula, GA 30019",
    price: 440000,
    image: "https://www.redfin.com/GA/Dacula/1366-Rolling-View-Way-SE-30019/unit-244/home/112964892",
  };

  return (
    <div className="max-w-sm border rounded-lg overflow-hidden shadow hover:shadow-lg transition">
      <img
        src={property.image}
        alt={property.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold">{property.title}</h3>
        <p className="text-gray-600">{property.location}</p>
        <p className="text-blue-600 font-bold">
          {property.price.toLocaleString("en-US", {
            style: "currency",
            currency: "USD",
          })}
        </p>
      </div>
    </div>
  );
};

export default PropertyCard;

