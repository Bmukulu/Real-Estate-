import { useState } from "react";

export default function ImageCarousel() {
  //  Property images for 1366 Rolling View Way
  const images = [
    "https://ssl.cdn-redfin.com/photo/244/112/964/112964892_0.jpg",
    "https://ssl.cdn-redfin.com/photo/244/112/964/112964892_1.jpg",
    "https://ssl.cdn-redfin.com/photo/244/112/964/112964892_2.jpg",
    "https://ssl.cdn-redfin.com/photo/244/112/964/112964892_3.jpg",
    "https://ssl.cdn-redfin.com/photo/244/112/964/112964892_4.jpg"
  ];

  const [index, setIndex] = useState(0);

  const nextImage = () => {
    setIndex((index + 1) % images.length);
  };

  const prevImage = () => {
    setIndex((index - 1 + images.length) % images.length);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "20px" }}>
      {/* IMAGE */}
      <img
        src={images[index]}
        alt="Property"
        style={{
          width: "450px",
          height: "300px",
          objectFit: "cover",
          borderRadius: "12px",
          boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
        }}
      />

      {/* BUTTONS */}
      <div style={{ marginTop: "12px" }}>
        <button onClick={prevImage} style={btnStyle}>
          ⟵ Prev
        </button>

        <button onClick={nextImage} style={btnStyle}>
          Next ⟶
        </button>
      </div>

      {/* DOT INDICATORS */}
      <div style={{ marginTop: "10px" }}>
        {images.map((_, i) => (
          <span
            key={i}
            style={{
              height: "10px",
              width: "10px",
              margin: "0 4px",
              display: "inline-block",
              borderRadius: "50%",
              backgroundColor: i === index ? "#333" : "#bbb",
            }}
          />
        ))}
      </div>
    </div>
  );
}

const btnStyle = {
  padding: "8px 16px",
  margin: "0 8px",
  borderRadius: "6px",
  border: "none",
  cursor: "pointer",
  fontSize: "14px",
  backgroundColor: "#0077ff",
  color: "white",
};
