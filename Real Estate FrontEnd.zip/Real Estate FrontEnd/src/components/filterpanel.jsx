import React, { useState } from "react";

const FilterPanel = ({ properties, onFilter }) => {
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [bedrooms, setBedrooms] = useState("");
  const [bathrooms, setBathrooms] = useState("");
  const [propertyType, setPropertyType] = useState("");

  const handleFilter = () => {
    const filtered = properties.filter((p) => {
      const matchesMinPrice = minPrice ? p.price >= Number(minPrice) : true;
      const matchesMaxPrice = maxPrice ? p.price <= Number(maxPrice) : true;
      const matchesBedrooms = bedrooms ? p.bedrooms === Number(bedrooms) : true;
      const matchesBathrooms = bathrooms ? p.bathrooms === Number(bathrooms) : true;
      const matchesType = propertyType ? p.type === propertyType : true;

      return matchesMinPrice && matchesMaxPrice && matchesBedrooms && matchesBathrooms && matchesType;
    });

    onFilter(filtered);
  };

  return (
    <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginBottom: "20px" }}>
      <input
        type="number"
        placeholder="Min Price"
        value={minPrice}
        onChange={(e) => { setMinPrice(e.target.value); handleFilter(); }}
      />
      <input
        type="number"
        placeholder="Max Price"
        value={maxPrice}
        onChange={(e) => { setMaxPrice(e.target.value); handleFilter(); }}
      />
      <input
        type="number"
        placeholder="Bedrooms"
        value={bedrooms}
        onChange={(e) => { setBedrooms(e.target.value); handleFilter(); }}
      />
      <input
        type="number"
        placeholder="Bathrooms"
        value={bathrooms}
        onChange={(e) => { setBathrooms(e.target.value); handleFilter(); }}
      />
      <select
        value={propertyType}
        onChange={(e) => { setPropertyType(e.target.value); handleFilter(); }}
      >
        <option value="">All Types</option>
        <option value="House">House</option>
        <option value="Condo">Condo</option>
        <option value="Apartment">Apartment</option>
      </select>
    </div>
  );
};

export default FilterPanel;
