def calculate_mortgage(price, down_payment, interest_rate, years):
    principal = price - down_payment
    monthly_rate = interest_rate / 100 / 12
    n = years * 12

    if monthly_rate == 0:
        return principal / n

    payment = (principal * monthly_rate) / (1 - (1 + monthly_rate) ** -n)
    return round(payment, 2)


# ---- Program Starts Here ----
print("🏠 Mortgage Calculator")

price = float(input("Home price: "))
down_payment = float(input("Down payment: "))
interest_rate = float(input("Interest rate (%): "))
years = int(input("Term (years): "))

monthly_payment = calculate_mortgage(price, down_payment, interest_rate, years)

print(f"\nYour monthly payment is: ${monthly_payment}")
