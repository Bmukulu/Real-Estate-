import React, { useState } from "react";

const SearchBar = ({ properties, onSearch }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const handleChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);

    const filtered = properties.filter(
      (p) =>
        p.name.toLowerCase().includes(value.toLowerCase()) ||
        p.city.toLowerCase().includes(value.toLowerCase())
    );

    onSearch(filtered);
  };

  return (
    <input
      type="text"
      placeholder="Search by city or property name..."
      value={searchTerm}
      onChange={handleChange}
      style={{ padding: "8px", width: "300px", marginBottom: "20px" }}
    />
  );
};

export default SearchBar;
