// src/components/ComparePanel.jsx

import React from "react";

export default function ComparePanel({ properties = [] }) {
  if (properties.length === 0) {
    return (
      <div style={styles.empty}>
        <p>No properties selected for comparison.</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {properties.map((property, index) => (
        <div key={index} style={styles.card}>
          <img
            src={property.images?.[0]}
            alt="property"
            style={styles.image}
          />

          <h2 style={styles.address}>{property.address}</h2>

          <p><strong>Price:</strong> ${property.price.toLocaleString()}</p>
          <p><strong>Beds:</strong> {property.beds}</p>
          <p><strong>Baths:</strong> {property.baths}</p>
          <p><strong>Sqft:</strong> {property.sqft}</p>
          <p><strong>Year Built:</strong> {property.yearBuilt}</p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  empty: {
    textAlign: "center",
    padding: "40px",
    fontSize: "18px",
  },
  container: {
    display: "flex",
    gap: "20px",
    overflowX: "auto",
    padding: "20px",
  },
  card: {
    minWidth: "300px",
    border: "1px solid #ddd",
    borderRadius: "12px",
    padding: "16px",
    background: "#fff",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  },
  image: {
    width: "100%",
    height: "180px",
    objectFit: "cover",
    borderRadius: "10px",
    marginBottom: "10px",
  },
  address: {
    fontSize: "18px",
    marginBottom: "10px",
  },
};
