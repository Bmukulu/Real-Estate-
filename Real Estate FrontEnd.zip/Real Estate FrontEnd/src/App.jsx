import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import "./pages/home";
import "./pages/Listings";
import "./pages/PropertyDetail";
import "./pages/Login";
import  "./pages/Dashboard";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/listings" element={<Listings />} />
        <Route path="/property/:id" element={<PropertyDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/calculator" element={<MortgageCalculator />} />
      </Routes>
    </Router>
  );
}

export default App;
